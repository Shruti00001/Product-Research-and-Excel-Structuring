"""SQL + statistics + charts on data/products.csv. Run: python analysis.py"""
import os, re, sqlite3
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from scipy import stats

os.makedirs("outputs", exist_ok=True)
df = pd.read_csv("data/products.csv")
con = sqlite3.connect(":memory:")
df.to_sql("products", con, index=False)

# ---- 1. SQL analysis (CTEs, window functions, subqueries) ----
sql = open("sql/queries.sql").read()
for name, q in re.findall(r"-- name: (\w+)[^\n]*\n(.*?)(?=-- name:|\Z)", sql, flags=re.S):
    res = pd.read_sql_query(q, con)
    res.to_csv(f"outputs/{name}.csv", index=False)
    print(f"\n=== {name} ===\n{res.to_string(index=False)}")

# ---- 2. Statistics ----
print("\n=== STATISTICS ===")
amazon = df[df.platform == "Amazon"].rating
others = df[df.platform != "Amazon"].rating
t, p = stats.ttest_ind(amazon, others, equal_var=False)
print(f"Welch t-test, rating Amazon vs other platforms: t={t:.2f}, p={p:.4f}")

groups = [g.rating.values for _, g in df.groupby("category")]
f, p = stats.f_oneway(*groups)
print(f"One-way ANOVA, rating across categories: F={f:.2f}, p={p:.4f}")

r, p = stats.pearsonr(df.price, df.rating)
rho, p2 = stats.spearmanr(df.price, df.rating)
print(f"Price vs rating: Pearson r={r:.2f} (p={p:.4f}), Spearman rho={rho:.2f} (p={p2:.4f})")

chi, p, dof, _ = stats.chi2_contingency(pd.crosstab(df.platform, df.category))
print(f"Chi-square, platform x category: chi2={chi:.1f}, dof={dof}, p={p:.4g}")
print("Rule used: p < 0.05 -> statistically significant. Data is SIMULATED (see README).")

# ---- 3. Charts ----
df.platform.value_counts().plot.pie(autopct="%1.0f%%", ylabel="", title="Products by platform")
plt.savefig("outputs/platform_distribution.png", dpi=150, bbox_inches="tight"); plt.clf()
for c, g in df.groupby("category"):
    plt.scatter(g.price, g.rating, label=c, alpha=.6)
plt.xscale("log"); plt.xlabel("Price (INR, log scale)"); plt.ylabel("Rating")
plt.title("Price vs rating"); plt.legend()
plt.savefig("outputs/price_vs_rating.png", dpi=150, bbox_inches="tight"); plt.clf()
df.groupby("brand").rating.mean().sort_values().tail(10).plot.barh(title="Top 10 brands by avg rating")
plt.savefig("outputs/avg_rating_by_brand.png", dpi=150, bbox_inches="tight")
print("\nSaved CSVs and charts to outputs/")
