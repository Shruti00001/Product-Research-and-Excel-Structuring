"""Builds Product_Research.xlsx: data sheets + formula-driven Summary + XLOOKUP Lookup sheet."""
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill

df = pd.read_csv("data/products.csv")
feat = pd.read_csv("data/feature_matrix.csv"); sent = pd.read_csv("data/customer_sentiment.csv")
wb = Workbook(); hdr = PatternFill("solid", fgColor="1F3A5F"); white = Font(bold=True, color="FFFFFF")

def sheet(ws, frame):
    ws.append(list(frame.columns))
    for row in frame.itertuples(index=False): ws.append(list(row))
    for c in ws[1]: c.fill, c.font = hdr, white
    for col in ws.columns: ws.column_dimensions[col[0].column_letter].width = 22

ws = wb.active; ws.title = "Products"; sheet(ws, df)
sheet(wb.create_sheet("Features"), feat); sheet(wb.create_sheet("Sentiment"), sent)
n = len(df) + 1

s = wb.create_sheet("Summary")
s.append(["Platform", "Products", "Avg Price", "Avg Rating", "Total Reviews"])
for i, p in enumerate(sorted(df.platform.unique()), start=2):
    s.append([p, f'=COUNTIFS(Products!$H$2:$H${n},A{i})',
              f'=ROUND(AVERAGEIFS(Products!$E$2:$E${n},Products!$H$2:$H${n},A{i}),0)',
              f'=ROUND(AVERAGEIFS(Products!$F$2:$F${n},Products!$H$2:$H${n},A{i}),2)',
              f'=SUMIFS(Products!$G$2:$G${n},Products!$H$2:$H${n},A{i})'])
for c in s[1]: c.fill, c.font = hdr, white

lk = wb.create_sheet("Lookup")
lk["A1"], lk["B1"] = "Type a product name:", "NovaTech Smartwatch"
for r, (lab, col) in enumerate([("Price", "E"), ("Rating", "F"), ("Reviews", "G"), ("Platform", "H")], start=3):
    lk[f"A{r}"] = lab
    lk[f"B{r}"] = f'=XLOOKUP($B$1,Products!$B$2:$B${n},Products!${col}$2:${col}${n},"not found")'
lk["A8"], lk["B8"] = "Unique selling point", '=XLOOKUP($B$1,Features!$A:$A,Features!$D:$D,"n/a (only first 5 products have feature data)")'
lk.column_dimensions["A"].width = 24; lk.column_dimensions["B"].width = 42
wb.save("Product_Research.xlsx"); print("Product_Research.xlsx created")
