# Product Research & Excel Structuring

Competitor-style product analysis on a **simulated** e-commerce dataset (Amazon, Flipkart, Myntra, Nykaa):
data structuring, SQL analysis, statistical testing, an Excel workbook with formulas, and Power BI assets.

> **Data note:** all data is simulated. `data/products.csv` has 200 products: 5 hand-written seed products
> (`seed_data.py`) plus 195 generated with a fixed random seed (`generate_data.py`). Nothing was scraped.
> Findings below demonstrate the analysis method, not real market facts.

## Stack
Python (pandas, NumPy, SciPy, Matplotlib), SQL (SQLite: CTEs, window functions, subqueries),
Excel (formulas, XLOOKUP, AVERAGEIFS/COUNTIFS), Power Query (M), Power BI (DAX), Statistics

## Project structure
| Path | What it does |
|---|---|
| `seed_data.py` | Writes the 3 original tables: product overview, feature matrix, customer sentiment |
| `generate_data.py` | Builds `data/products.csv` (200 simulated products, seed = 42) |
| `sql/queries.sql` | 5 analysis queries: RANK, ROW_NUMBER, NTILE, AVG() OVER, correlated subquery |
| `analysis.py` | Runs the SQL, statistical tests and charts; saves results to `outputs/` |
| `build_excel.py` | Builds `Product_Research.xlsx` (data sheets, formula Summary, XLOOKUP lookup) |
| `powerquery/clean_products.m` | Power Query steps: types, trimming, de-duplication, price bands |
| `powerbi/measures.dax` | DAX measures: avg rating, review-weighted rating, price vs category average |

## Run it
```bash
pip install -r requirements.txt
python seed_data.py && python generate_data.py
python analysis.py        # SQL results, statistics, charts -> outputs/
python build_excel.py     # Product_Research.xlsx
```

## Statistical tests (`analysis.py`)
- Welch t-test: rating, Amazon vs other platforms
- One-way ANOVA: rating across categories
- Pearson and Spearman correlation: price vs rating
- Chi-square test: platform vs category mix
Significance rule: p < 0.05.

## What the simulated data shows
- Ratings differ significantly across categories (ANOVA p < 0.001).
- Higher-priced products tend to have lower ratings (r = -0.31, p < 0.001); rating falls steadily from the cheapest to the most expensive price quartile.
- No significant rating difference between Amazon and other platforms (p = 0.97).
- Platform mix depends on category (chi-square p < 0.001), e.g. Nykaa is mostly skincare.
These patterns come from how the data was simulated. Applying the same code to real scraped data is the natural next step.

## Original seed data
The first 5 products, their feature matrix and the customer-sentiment table (keywords, complaints, suggestions)
are kept as hand-written tables in `data/`.
