"""Builds data/products.csv: 200 SIMULATED products (your 5 original rows + 195 generated).
All values are synthetic (fixed random seed) - findings show the METHOD, not real market facts."""
import numpy as np, pandas as pd

rng = np.random.default_rng(42)
N = 200
cats = ["Electronics", "Skincare", "Home Essentials"]
plat = ["Amazon", "Flipkart", "Myntra", "Nykaa"]
plat_w = {"Electronics": [.45, .40, .10, .05], "Skincare": [.20, .10, .30, .40],
          "Home Essentials": [.45, .45, .07, .03]}
price_mu = {"Electronics": 7.4, "Skincare": 6.4, "Home Essentials": 7.3}    # log-price means
rate_mu = {"Electronics": 4.1, "Skincare": 4.2, "Home Essentials": 4.3}
noun = {"Electronics": ["Smartwatch", "Headphones", "Speaker", "Earbuds", "Power Bank"],
        "Skincare": ["Serum", "Moisturizer", "Sunscreen", "Face Wash", "Toner"],
        "Home Essentials": ["Air Purifier", "Lamp", "Organizer", "Kettle", "Diffuser"]}
brands = {c: [f"{p}{s}" for p, s in zip(
    ["Nova", "Pulse", "Volt", "Zen", "Arc", "Glow", "Fresh", "Pure", "Derma", "Bloom", "Eco", "Home", "Nest", "Cozy", "Aura"][i*5:i*5+5],
    ["Tech", "Gear", "Wave", "Sound", "Byte", "Skin", "Aura", "Leaf", "Lab", "Veda", "Nest", "Craft", "Ware", "Haus", "Glow"][i*5:i*5+5])]
    for i, c in enumerate(cats)}

rows = []
for i in range(N - 5):
    c = rng.choice(cats, p=[.4, .35, .25])
    b = rng.choice(brands[c]); n = rng.choice(noun[c])
    p = round(float(np.exp(rng.normal(price_mu[c], .55))), 0)
    r = float(np.clip(rng.normal(rate_mu[c] - .00015 * (p if c != "Skincare" else 0), .35), 3.0, 5.0))
    rev = int(np.exp(rng.normal(6.4, .9)))
    s = float(np.clip(0.2 * (r - 4.2) + rng.normal(0, .12) + .5, 0, 1))
    rows.append([f"{b} {n}", b, c, p, round(r, 1), rev, rng.choice(plat, p=plat_w[c]), round(s, 2)])

seed = pd.read_csv("data/product_overview.csv")
seed.columns = ["product_name", "brand", "category", "price", "rating", "reviews", "platform"]
seed["sentiment_score"] = [0.72, 0.60, 0.78, 0.50, 0.65]     # hand-set for the 5 original products
gen = pd.DataFrame(rows, columns=seed.columns)
df = pd.concat([seed, gen], ignore_index=True)
df.insert(0, "product_id", range(1, len(df) + 1))
df.to_csv("data/products.csv", index=False)
print(df.shape); print(df.head())
